(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~add-product-add-product-module~login-login-module~order-detail-final-order-detail-final-modu~d086cb5e"],{

/***/ "./src/app/product.service.ts":
/*!************************************!*\
  !*** ./src/app/product.service.ts ***!
  \************************************/
/*! exports provided: ProductService, snapshotToArray */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductService", function() { return ProductService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "snapshotToArray", function() { return snapshotToArray; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");









var ProductService = /** @class */ (function () {
    function ProductService(storage, router, alertCtrl, events) {
        this.storage = storage;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.events = events;
        this.eventSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Subject"]();
        this.usertype = "visitor";
        this.db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
        this.products = [];
        this.orders = [];
        this.cart = [];
        this.prices_string = [];
        this.quantities_string = [];
        this.products_string = "";
        this.user = null;
        user = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser;
        var self = this;
        self.total_quantity = 0;
        self.total_price = 0;
        if (this.usertype == "visitor") {
            this.db.collection("products")
                .onSnapshot(function (querySnapshot) {
                console.log("products list changed...........1visitor");
                self.products = [];
                querySnapshot.forEach(function (doc) {
                    var product = doc.data();
                    // console.log(doc.id)
                    self.products.push({ name: product.name, price: product.price, category: product.category, photoUrl: product.photoUrl, description: product.description, id: doc.id, uid: product.uid });
                });
                //self.events.publish('dataloaded,Date.now());
                self.publishEvent({
                    foo: 'bar'
                });
                console.log("products reloaded");
            });
            //#############################################################
            //#############################################################
            //#############################################################
            var user = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser;
            if ((user != null)) {
                self.orders = [];
                this.db.collection("orders").where("uid", "==", firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid)
                    .onSnapshot(function (querySnapshot) {
                    console.log("orders list changed...........1visitor");
                    self.orders = [];
                    querySnapshot.forEach(function (doc) {
                        var order = doc.data();
                        // console.log(doc.id)
                        self.orders.push({ total: order.total, numItems: order.numItems,
                            productName: order.productName, orderDate: order.orderDate, uid: order.uid });
                    });
                    //self.events.publish('dataloaded,Date.now());
                    self.publishEvent({
                        foo: 'bar'
                    });
                    console.log("products reloaded");
                });
                self.cart = [];
                this.db.collection("cart").where("uid", "==", firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid)
                    .onSnapshot(function (querySnapshot) {
                    console.log("orders list changed...........1visitor");
                    self.cart = [];
                    querySnapshot.forEach(function (doc) {
                        var cart = doc.data();
                        self.cart.push({ total_price: cart.total_price, total_quantity: cart.total_quantity, orderDate: cart.orderDate, id: doc.id, uid: cart.uid, prices_string: cart.prices_string,
                            quantities_string: cart.quantities_string, products_string: cart.products_string, cart_id: cart.cart_id });
                    });
                    //self.events.publish('dataloaded,Date.now());
                    self.publishEvent({
                        foo: 'bar'
                    });
                    console.log("products reloaded");
                });
            }
            //#############################################################
            //#############################################################
            //#############################################################
        }
        else {
            this.db.collection("products")
                .onSnapshot(function (querySnapshot) {
                console.log("products list changed...........2 owner");
                self.products = [];
                querySnapshot.forEach(function (doc) {
                    var product = doc.data();
                    self.products.push({ name: product.name, price: product.price, category: product.category, photoUrl: product.photoUrl, description: product.description, id: doc.id, uid: product.uid });
                });
                self.publishEvent({
                    foo: 'bar'
                });
                console.log("products reloaded");
            });
            self.publishEvent({
                foo: 'bar'
            });
            console.log("products reloaded");
            self.cart = [];
            self.orders = [];
        }
    } //end of constructor
    //event notification
    ProductService.prototype.publishEvent = function (data) {
        this.eventSubject.next(data);
    };
    ProductService.prototype.getObservable = function () {
        return this.eventSubject;
    };
    ProductService.prototype.setUsertype = function (type) {
        var user = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser;
        var self = this;
        this.usertype = type;
        console.log("usertype set as: " + type);
        if (type == "signout") {
            this.db.collection("products")
                .onSnapshot(function (querySnapshot) {
                console.log("products list changed...........");
                self.products = [];
                querySnapshot.forEach(function (doc) {
                    var product = doc.data();
                    self.products.push({ name: product.name, price: product.price, category: product.category, photoUrl: product.photoUrl, description: product.description, id: doc.id, uid: product.uid });
                });
                //self.events.publish('dataloaded',Date.now());
                self.publishEvent({
                    foo: 'bar'
                });
                console.log("products reloaded");
            });
            this.orders = [];
            this.cart = [];
        }
        if (this.usertype == "visitor") {
            this.db.collection("products")
                .onSnapshot(function (querySnapshot) {
                console.log("products list changed...........");
                self.products = [];
                querySnapshot.forEach(function (doc) {
                    var product = doc.data();
                    self.products.push({ name: product.name, price: product.price, category: product.category, photoUrl: product.photoUrl, description: product.description, id: doc.id, uid: product.uid });
                });
                //self.events.publish('dataloaded',Date.now());
                self.publishEvent({
                    foo: 'bar'
                });
                console.log("products reloaded");
            });
            self.orders = [];
            self.cart = [];
            if ((user != null)) {
                self.orders = [];
                self.cart = [];
                this.db.collection("orders").where("uid", "==", firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid)
                    .onSnapshot(function (querySnapshot) {
                    console.log("orders list changed...........1visitor");
                    self.orders = [];
                    querySnapshot.forEach(function (doc) {
                        var order = doc.data();
                        // console.log(doc.id)
                        self.orders.push({ total: order.total, numItems: order.numItems,
                            productName: order.productName, orderDate: order.orderDate, uid: order.uid, id: doc.id });
                    });
                    //self.events.publish('dataloaded,Date.now());
                    self.publishEvent({
                        foo: 'bar'
                    });
                    console.log("products reloaded");
                });
                self.cart = [];
                this.db.collection("cart").where("uid", "==", firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid)
                    .onSnapshot(function (querySnapshot) {
                    console.log("orders list changed...........1visitor");
                    self.cart = [];
                    querySnapshot.forEach(function (doc) {
                        var cart = doc.data();
                        self.cart.push({ total_price: cart.total_price, total_quantity: cart.total_quantity, orderDate: cart.orderDate, id: doc.id, uid: cart.uid, prices_string: cart.prices_string,
                            quantities_string: cart.quantities_string, products_string: cart.products_string, cart_id: cart.cart_id });
                    });
                    //self.events.publish('dataloaded,Date.now());
                    self.publishEvent({
                        foo: 'bar'
                    });
                    console.log("products reloaded");
                }
                //INSERT HERE ############################
                );
            }
        }
        else {
            this.db.collection("products").where("uid", "==", firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid)
                .onSnapshot(function (querySnapshot) {
                console.log("products list changed...........");
                self.products = [];
                querySnapshot.forEach(function (doc) {
                    var product = doc.data();
                    self.products.push({ name: product.name, price: product.price, category: product.category, photoUrl: product.photoUrl, description: product.description, id: doc.id, uid: product.uid });
                });
                // self.events.publish('dataloaded',Date.now());
                self.publishEvent({
                    foo: 'bar'
                });
                console.log("products reloaded");
            });
        }
    };
    ProductService.prototype.getUserType = function () {
        return this.usertype;
    };
    ProductService.prototype.getProducts = function () {
        var _this = this;
        var productsObservable = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Observable"](function (observer) {
            setTimeout(function () {
                observer.next(_this.products);
            }, 1000);
        });
        return productsObservable;
    };
    ProductService.prototype.addProduct = function (name, price, category, photoUrl, description) {
        var self = this;
        var uid = null;
        if (firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser != null) {
            uid = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
            console.log(uid, " :****** uid");
        }
        else {
            console.log(" no user logged in, no product created");
        }
        var db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
        db.collection("products").add({
            'uid': uid,
            'name': name,
            'price': price,
            'category': category,
            'photoUrl': photoUrl,
            'description': description
        })
            .then(function (docRef) {
            console.log("Document written with ID: ", docRef.id);
            //update this products arrays
        })
            .catch(function (error) {
            console.error("Error adding document: ", error);
        });
    };
    ProductService.prototype.getOrders = function () {
        var _this = this;
        var ordersObservable = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Observable"](function (observer) {
            setTimeout(function () {
                observer.next(_this.orders);
            }, 1000);
        });
        return ordersObservable;
    };
    ProductService.prototype.addOrder = function (total, numItems, productName, orderDate) {
        var self = this;
        var uid = null;
        if (firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser != null) {
            uid = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
            console.log(uid, " :****** uid");
            var db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
            db.collection("orders").add({
                'total': total,
                'numItems': numItems,
                'productName': productName,
                'orderDate': orderDate,
                'uid': uid
            })
                .then(function (docRef) {
                console.log("Document written with ID: ", docRef.id);
                //update this products arrays
            })
                .catch(function (error) {
                console.error("Error adding document: ", error);
            });
        }
        else {
            console.log(" no user logged in, no order created");
            this.presentNotVisitor();
        }
    };
    ProductService.prototype.updateQuantityPrice = function () {
        var self = this;
        var uid = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
        self.total_price = 0;
        self.total_quantity = 0;
        self.prices_string = [];
        self.products_string = "";
        self.quantities_string = [];
        this.db.collection("orders").where("uid", "==", firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid)
            .onSnapshot(function (querySnapshot) {
            querySnapshot.forEach(function (doc) {
                var order = doc.data();
                // console.log(doc.id)
                self.updateTotalPrice(order.total);
                self.updateTotalQuantity(order.numItems);
                self.updatePriceString(String(order.total));
                self.updateQuantitiesString(String(order.numItems));
                self.updateProductsString(String(order.productName));
            });
            //self.events.publish('dataloaded,Date.now());
            self.publishEvent({
                foo: 'bar'
            });
            console.log("products reloaded");
            console.log(self.total_price);
        });
    };
    ProductService.prototype.updatePriceString = function (string) {
        this.prices_string.push(string);
    };
    ProductService.prototype.updateQuantitiesString = function (string) {
        this.quantities_string.push(string);
    };
    ProductService.prototype.updateProductsString = function (string) {
        this.products_string = string + ", " + this.products_string;
    };
    ProductService.prototype.updateTotalPrice = function (toAdd) {
        this.total_price += toAdd;
        console.log(toAdd);
        console.log(this.total_price);
    };
    ProductService.prototype.updateTotalQuantity = function (toAdd) {
        this.total_quantity += toAdd;
    };
    ProductService.prototype.pushCartToFirebase = function (cart_id, orderDate, totalPrice, totalQuantity, products_string, quantities_string, prices_string) {
        var self = this;
        var uid = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
        console.log(uid, " :****** uid");
        var db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
        db.collection("cart").add({
            'total_price': totalPrice,
            'total_quantity': totalQuantity,
            'orderDate': orderDate,
            'quantities_string': quantities_string,
            'price_string': prices_string,
            'products_string': products_string,
            'uid': uid,
            'cart_id': cart_id
        })
            .then(function (docRef) {
            console.log("Document written with ID: ", docRef.id);
            //update this products arrays
        })
            .catch(function (error) {
            console.error("Error adding document: ", error);
        });
    };
    ProductService.prototype.getCart = function () {
        var _this = this;
        var cartObservable = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Observable"](function (observer) {
            setTimeout(function () {
                observer.next(_this.cart);
            }, 1000);
        });
        return cartObservable;
    };
    ProductService.prototype.deleteProduct = function (id) {
        if (this.usertype == "owner") {
            var self = this;
            var db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
            db.collection("products").doc(id).delete().then(function () {
                console.log("Document successfully deleted!");
                console.log("Product deleted:" + id);
                self.router.navigate(["/tabs/product-list"]);
            }).catch(function (error) {
                console.error("Error removing document: ", error);
            });
        }
        else {
            // YOU ARE NOT AN OWNER AND CANNOT DELETE A PRODUCT
        }
    };
    ProductService.prototype.deleteOrder = function (id) {
        if (this.usertype == "visitor") {
            var self = this;
            var db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
            db.collection("orders").doc(id).delete().then(function () {
                console.log("Document successfully deleted!");
                console.log("Order deleted:" + id);
                self.router.navigate(["/tabs/product-list"]);
            }).catch(function (error) {
                console.error("Error removing document: ", error);
            });
        }
        else {
            // YOU ARE NOT A VISITOR AND CANNOT DELETE AN ORDER
        }
    };
    ProductService.prototype.deleteOrderFinal = function (id) {
        if (this.usertype == "visitor") {
            var self = this;
            var db = firebase__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
            db.collection("cart").doc(id).delete().then(function () {
                console.log("Document successfully deleted!");
                console.log("Order deleted:" + id);
                self.router.navigate(["/tabs/product-list"]);
            }).catch(function (error) {
                console.error("Error removing document: ", error);
            });
        }
        else {
            // YOU ARE NOT A VISITOR AND CANNOT DELETE AN ORDER
        }
    };
    ProductService.prototype.presentNotVisitor = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: 'You are not logged in as a visitor and cannot place an order. Please log in as a visitor to place an order.',
                            buttons: [{
                                    text: 'Dismiss',
                                    handler: function () {
                                        console.log('No clicked');
                                    }
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductService.ctorParameters = function () { return [
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"] }
    ]; };
    ProductService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"]])
    ], ProductService);
    return ProductService;
}());

var snapshotToArray = function (snapshot) {
    var returnArr = [];
    snapshot.forEach(function (childSnapshot) {
        var product = childSnapshot.val();
        product.id = childSnapshot.key;
        // console.log(item);
        returnArr.push(product);
    });
    return returnArr;
};


/***/ })

}]);
//# sourceMappingURL=default~add-product-add-product-module~login-login-module~order-detail-final-order-detail-final-modu~d086cb5e.js.map