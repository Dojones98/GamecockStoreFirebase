(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-detail-final-order-detail-final-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/order-detail-final/order-detail-final.page.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-detail-final/order-detail-final.page.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title> Order Details</ion-title>\n        <ion-buttons slot = \"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n      <ion-buttons slot = \"end\">\n      <ion-button slot = \"end\" (click)=\"deleteOrderHelper()\"> Delete Order </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item>\n      Order ID : {{ cart.cart_id }}\n   </ion-item>\n    <ion-item>\n     Products: {{cart.products_string}}\n    </ion-item>\n    <ion-item>\n       Total Quantity: {{ cart.total_quantity }}\n    </ion-item>\n    <ion-item>\n       Price: ${{ cart.total_price}}\n    </ion-item>\n    <ion-item>\n       UID: {{ cart.uid }}\n    </ion-item>\n    <ion-item>\n       Date: {{ cart.orderDate }}\n    </ion-item>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/order-detail-final/order-detail-final-routing.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/order-detail-final/order-detail-final-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: OrderDetailFinalPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderDetailFinalPageRoutingModule", function() { return OrderDetailFinalPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _order_detail_final_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./order-detail-final.page */ "./src/app/order-detail-final/order-detail-final.page.ts");




var routes = [
    {
        path: '',
        component: _order_detail_final_page__WEBPACK_IMPORTED_MODULE_3__["OrderDetailFinalPage"]
    }
];
var OrderDetailFinalPageRoutingModule = /** @class */ (function () {
    function OrderDetailFinalPageRoutingModule() {
    }
    OrderDetailFinalPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], OrderDetailFinalPageRoutingModule);
    return OrderDetailFinalPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/order-detail-final/order-detail-final.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/order-detail-final/order-detail-final.module.ts ***!
  \*****************************************************************/
/*! exports provided: OrderDetailFinalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderDetailFinalPageModule", function() { return OrderDetailFinalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _order_detail_final_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-detail-final-routing.module */ "./src/app/order-detail-final/order-detail-final-routing.module.ts");
/* harmony import */ var _order_detail_final_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order-detail-final.page */ "./src/app/order-detail-final/order-detail-final.page.ts");







var OrderDetailFinalPageModule = /** @class */ (function () {
    function OrderDetailFinalPageModule() {
    }
    OrderDetailFinalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _order_detail_final_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderDetailFinalPageRoutingModule"]
            ],
            declarations: [_order_detail_final_page__WEBPACK_IMPORTED_MODULE_6__["OrderDetailFinalPage"]]
        })
    ], OrderDetailFinalPageModule);
    return OrderDetailFinalPageModule;
}());



/***/ }),

/***/ "./src/app/order-detail-final/order-detail-final.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/order-detail-final/order-detail-final.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVyLWRldGFpbC1maW5hbC9vcmRlci1kZXRhaWwtZmluYWwucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/order-detail-final/order-detail-final.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/order-detail-final/order-detail-final.page.ts ***!
  \***************************************************************/
/*! exports provided: OrderDetailFinalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderDetailFinalPage", function() { return OrderDetailFinalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../product.service */ "./src/app/product.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






var OrderDetailFinalPage = /** @class */ (function () {
    function OrderDetailFinalPage(route, router, productService, atrCtrl) {
        this.route = route;
        this.router = router;
        this.productService = productService;
        this.atrCtrl = atrCtrl;
        this.cart = null;
        this.product_array = [];
        this.price_array = [];
        this.quantities_array = [];
    }
    OrderDetailFinalPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.cart = param;
            console.log(_this.cart);
        });
        this.product_array = this.cart.products_string;
        this.price_array = this.cart.price_string;
        this.quantities_array = this.cart.quantities_string;
    };
    OrderDetailFinalPage.prototype.deleteOrderFinal = function () {
        console.log(this.cart);
        console.log(this.cart.id + " to be deleted");
        this.productService.deleteOrderFinal(this.cart.id);
        this.goBack();
    };
    OrderDetailFinalPage.prototype.goBack = function () {
        this.router.navigate(["/tabs/order-list-final"]);
    };
    OrderDetailFinalPage.prototype.deleteOrderHelper = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alertConfirm;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.atrCtrl.create({
                            message: 'Are you sure you want to delete this order?',
                            buttons: [
                                {
                                    text: 'No',
                                    role: 'cancel',
                                    handler: function () {
                                        console.log('No clicked');
                                    }
                                },
                                {
                                    text: 'Yes',
                                    handler: function () {
                                        console.log('Yes clicked');
                                        _this.deleteOrderFinal();
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alertConfirm = _a.sent();
                        return [4 /*yield*/, alertConfirm.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    OrderDetailFinalPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
    ]; };
    OrderDetailFinalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-order-detail-final',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./order-detail-final.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/order-detail-final/order-detail-final.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./order-detail-final.page.scss */ "./src/app/order-detail-final/order-detail-final.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], OrderDetailFinalPage);
    return OrderDetailFinalPage;
}());



/***/ })

}]);
//# sourceMappingURL=order-detail-final-order-detail-final-module.js.map