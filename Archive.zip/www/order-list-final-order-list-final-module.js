(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-list-final-order-list-final-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/order-list-final/order-list-final.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-list-final/order-list-final.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Order List</ion-title>\n        <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <ion-list>\n    <ion-item *ngFor=\"let order of (cart | async)\" (click) = \"goToCart(order)\">\n    <ion-grid>\n      <ion-row>\n        <ion-col align-self: center>\n          <div><h1>\n           OrderID: {{order.cart_id}}\n          </h1></div>\n        </ion-col>\n        <ion-col align-self: center>\n          <div><h1>\n           Quantity: {{order.total_quantity}}\n          </h1></div>\n        </ion-col>\n        <ion-col align-self: center>\n          <div><h2>\n           Price: ${{order.total_price}}\n          </h2></div>\n        </ion-col>\n        <ion-col align-self: center>\n          <div><h2>\n           Date: {{order.orderDate}}\n          </h2></div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    </ion-item>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/order-list-final/order-list-final-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/order-list-final/order-list-final-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: OrderListFinalPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderListFinalPageRoutingModule", function() { return OrderListFinalPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _order_list_final_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./order-list-final.page */ "./src/app/order-list-final/order-list-final.page.ts");




var routes = [
    {
        path: '',
        component: _order_list_final_page__WEBPACK_IMPORTED_MODULE_3__["OrderListFinalPage"]
    }
];
var OrderListFinalPageRoutingModule = /** @class */ (function () {
    function OrderListFinalPageRoutingModule() {
    }
    OrderListFinalPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], OrderListFinalPageRoutingModule);
    return OrderListFinalPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/order-list-final/order-list-final.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/order-list-final/order-list-final.module.ts ***!
  \*************************************************************/
/*! exports provided: OrderListFinalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderListFinalPageModule", function() { return OrderListFinalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _order_list_final_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-list-final-routing.module */ "./src/app/order-list-final/order-list-final-routing.module.ts");
/* harmony import */ var _order_list_final_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order-list-final.page */ "./src/app/order-list-final/order-list-final.page.ts");







var OrderListFinalPageModule = /** @class */ (function () {
    function OrderListFinalPageModule() {
    }
    OrderListFinalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _order_list_final_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderListFinalPageRoutingModule"]
            ],
            declarations: [_order_list_final_page__WEBPACK_IMPORTED_MODULE_6__["OrderListFinalPage"]]
        })
    ], OrderListFinalPageModule);
    return OrderListFinalPageModule;
}());



/***/ }),

/***/ "./src/app/order-list-final/order-list-final.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/order-list-final/order-list-final.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVyLWxpc3QtZmluYWwvb3JkZXItbGlzdC1maW5hbC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/order-list-final/order-list-final.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/order-list-final/order-list-final.page.ts ***!
  \***********************************************************/
/*! exports provided: OrderListFinalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderListFinalPage", function() { return OrderListFinalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../product.service */ "./src/app/product.service.ts");





var OrderListFinalPage = /** @class */ (function () {
    function OrderListFinalPage(router, changeRef, productService) {
        var _this = this;
        this.router = router;
        this.changeRef = changeRef;
        this.productService = productService;
        this.cart = [];
        this.productService.getObservable().subscribe(function (data) {
            console.log('Data Received order list final', data);
            _this.cart = _this.productService.getCart();
        });
        this.cart = this.productService.cart;
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
        this.mySubscription = this.router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                // Trick the Router into believing it's last link wasn't previously loaded
                _this.router.navigated = false;
            }
        });
    }
    OrderListFinalPage.prototype.goToCart = function (cart) {
        console.log(cart);
        this.router.navigate(["/order-detail-final", cart]);
    };
    OrderListFinalPage.prototype.ngOnInit = function () {
        this.cart = this.productService.getCart();
        console.log(this.cart.length);
        if (this.productService.usertype == "undefined") {
            this.productService.usertype = "visitor";
            console.log(this.productService);
        }
        this.changeRef.detectChanges();
    };
    OrderListFinalPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
        { type: _product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"] }
    ]; };
    OrderListFinalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-order-list-final',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./order-list-final.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/order-list-final/order-list-final.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./order-list-final.page.scss */ "./src/app/order-list-final/order-list-final.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"]])
    ], OrderListFinalPage);
    return OrderListFinalPage;
}());



/***/ })

}]);
//# sourceMappingURL=order-list-final-order-list-final-module.js.map