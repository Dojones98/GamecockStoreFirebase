(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["product-list-product-list-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n<ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot = \"end\">\n      <ion-button (click) = \"openAddProductPage()\">\n        <ion-icon slot = \"icon-only\" name= \"add-circle\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"login()\" fill = \"outline\">\n        login\n      </ion-button>\n      <ion-button (click)=\"logout()\" fill = \"outline\">\n        logout\n      </ion-button>\n    </ion-buttons>\n    <ion-title color = \"dark\" size = \"large\">\n     Gamecock Store\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <h4><ion-img [src] = \"imgFile\"></ion-img></h4>\n  <ion-list>\n    <ion-item *ngFor=\"let product of (products | async)\" (click)=\"goToProduct(product)\">\n    <ion-grid>\n      <ion-row>\n        <ion-col align-self: center>\n          <div><h1>\n            {{product.name}}\n          </h1></div>\n        </ion-col>\n        <ion-col align-self: center>\n          <div><h2>\n            ${{product.price}}\n          </h2></div>\n        </ion-col>\n        <ion-col align-self: center>\n          <div><h2>\n            {{product.category}}\n          </h2></div>\n        </ion-col>\n        <ion-col align-self-end>\n          <div><h3>\n            <ion-thumbnail slot = \"end\">\n              <ion-img [src] = \"product.photoUrl\" style=\"align-self: end;\"></ion-img>\n            </ion-thumbnail>\n          </h3></div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    </ion-item>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/product-list/product-list-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/product-list/product-list-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: ProductListPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPageRoutingModule", function() { return ProductListPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _product_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-list.page */ "./src/app/product-list/product-list.page.ts");




var routes = [
    {
        path: '',
        component: _product_list_page__WEBPACK_IMPORTED_MODULE_3__["ProductListPage"]
    }
];
var ProductListPageRoutingModule = /** @class */ (function () {
    function ProductListPageRoutingModule() {
    }
    ProductListPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ProductListPageRoutingModule);
    return ProductListPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/product-list/product-list.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/product-list/product-list.module.ts ***!
  \*****************************************************/
/*! exports provided: ProductListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPageModule", function() { return ProductListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _product_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./product-list-routing.module */ "./src/app/product-list/product-list-routing.module.ts");
/* harmony import */ var _product_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./product-list.page */ "./src/app/product-list/product-list.page.ts");







var ProductListPageModule = /** @class */ (function () {
    function ProductListPageModule() {
    }
    ProductListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _product_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductListPageRoutingModule"]
            ],
            declarations: [_product_list_page__WEBPACK_IMPORTED_MODULE_6__["ProductListPage"]]
        })
    ], ProductListPageModule);
    return ProductListPageModule;
}());



/***/ }),

/***/ "./src/app/product-list/product-list.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/product-list/product-list.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("h1 {\n  text-align: left;\n  font-size: 20px;\n}\n\nh2 {\n  text-align: center;\n  font-size: 15px;\n}\n\nh3 {\n  vertical-align: middle;\n}\n\nh4 {\n  max-width: 500px;\n  margin-left: auto;\n  margin-right: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9kYW5pZWxqb25lcy9Eb2N1bWVudHMvR2l0SHViL0NTQ0VfNTQ2L0dhbWVjb2NrU3RvcmVfZGFuaWVsX2pvbmVzL3NyYy9hcHAvcHJvZHVjdC1saXN0L3Byb2R1Y3QtbGlzdC5wYWdlLnNjc3MiLCJzcmMvYXBwL3Byb2R1Y3QtbGlzdC9wcm9kdWN0LWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLHNCQUFBO0FDQ0o7O0FER0E7RUFDSSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QtbGlzdC9wcm9kdWN0LWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDEge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufVxuXG5oMiB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuaDMge1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgXG59XG5cbmg0IHtcbiAgICBtYXgtd2lkdGg6IDUwMHB4O1xuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICAgIG1hcmdpbi1yaWdodDogYXV0bztcbn0iLCJoMSB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuaDIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuaDMge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG5oNCB7XG4gIG1heC13aWR0aDogNTAwcHg7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59Il19 */");

/***/ }),

/***/ "./src/app/product-list/product-list.page.ts":
/*!***************************************************!*\
  !*** ./src/app/product-list/product-list.page.ts ***!
  \***************************************************/
/*! exports provided: ProductListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPage", function() { return ProductListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../product.service */ "./src/app/product.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var ProductListPage = /** @class */ (function () {
    function ProductListPage(router, productService, alertCtrl) {
        var _this = this;
        this.router = router;
        this.productService = productService;
        this.alertCtrl = alertCtrl;
        this.imgFile = "/assets/cover.png";
        this.showLogout = null;
        this.showLogin = null;
        this.products = [];
        /*
            if(this.productService.user == null) {
              this.showLogin = true;
              this.showLogout = false;
            } else if (this.productService.user == null) {
              this.showLogin = false;
              this.showLogout = true;
            }
        
        */
        this.productService.getObservable().subscribe(function (data) {
            console.log('Data Received product list', data);
            _this.products = _this.productService.getProducts();
        });
        this.products = this.productService.products;
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
        this.mySubscription = this.router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                // Trick the Router into believing it's last link wasn't previously loaded
                _this.router.navigated = false;
            }
        });
    }
    ProductListPage.prototype.ngOnInit = function () {
        if (this.productService.user == null) {
            console.log("Current User is null");
            this.productService.setUsertype("visitor");
        }
        this.products = this.productService.getProducts();
        console.log(this.products.length);
    };
    ProductListPage.prototype.ngOnDestroy = function () {
        if (this.mySubscription) {
            this.mySubscription.unsubscribe();
        }
    };
    ProductListPage.prototype.goToProduct = function (product) {
        console.log(product);
        this.router.navigate(["/product-detail", product]);
    };
    ProductListPage.prototype.openAddProductPage = function () {
        if (this.productService.usertype != "owner") {
            this.addProductError();
        }
        else {
            this.router.navigate(["/add-product"]);
        }
    };
    ProductListPage.prototype.login = function () {
        if (firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser != null) {
            this.presentLogin();
        }
        else {
            this.router.navigate(["/login"]);
        }
    };
    ProductListPage.prototype.logout = function () {
        if (firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser == null) {
            this.presentLogout();
        }
        else {
            var self = this;
            firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().signOut().then(function () {
                // Sign-out successful.
                console.log("logout ok. Byebye");
                self.router.navigate(["/login"]);
                self.productService.setUsertype("signout");
            }).catch(function (error) {
                // An error happened.
            });
            //reset usertype to visitor
            //this.productService.setUsertype("visitor");
            this.productService.orders = [];
        }
    };
    ProductListPage.prototype.presentLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: 'Login Error: You are already logged in.',
                            buttons: [{
                                    text: 'Dismiss',
                                    handler: function () {
                                        console.log('No clicked');
                                    }
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductListPage.prototype.presentLogout = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: 'Logout Error: You are not currently logged in.',
                            buttons: [{
                                    text: 'Dismiss',
                                    handler: function () {
                                        console.log('No clicked');
                                    }
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductListPage.prototype.addProductError = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: 'You can not add a product as a visitor. Please log in as an owner to add a product.',
                            buttons: [{
                                    text: 'Dismiss',
                                    handler: function () {
                                        console.log('No clicked');
                                    }
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductListPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
    ]; };
    ProductListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-product-list',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./product-list.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./product-list.page.scss */ "./src/app/product-list/product-list.page.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], ProductListPage);
    return ProductListPage;
}());



/***/ })

}]);
//# sourceMappingURL=product-list-product-list-module.js.map